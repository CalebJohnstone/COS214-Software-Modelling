#include "levelTwoStrategy.h"

//constructor and destructor
levelTwoStrategy::levelTwoStrategy(){

}

levelTwoStrategy::~levelTwoStrategy(){

}

//methods
string levelTwoStrategy::takeAction(){
    return " is spreading faster. We are forced to close public spaces.";
}