#include "levelFiveStrategy.h"

//constructor and destructor
levelFiveStrategy::levelFiveStrategy(){

}

levelFiveStrategy::~levelFiveStrategy(){

}

//methods
string levelFiveStrategy::takeAction(){
    return " is extremely dangerous. Deploying the army. Shutting down the economy";
}