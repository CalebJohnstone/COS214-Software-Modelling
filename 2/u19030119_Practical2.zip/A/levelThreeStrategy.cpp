#include "levelThreeStrategy.h"

//constructor and destructor
levelThreeStrategy::levelThreeStrategy(){

}

levelThreeStrategy::~levelThreeStrategy(){

}

//methods
string levelThreeStrategy::takeAction(){
    return " is getting a bit more dangerous. Stopping all domestic flights. Banning the sale of alcohol and tobacco (shutting down the strip)";
}