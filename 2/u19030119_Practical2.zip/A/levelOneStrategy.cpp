#include "levelOneStrategy.h"

//constructor and destructor
levelOneStrategy::levelOneStrategy(){

}

levelOneStrategy::~levelOneStrategy(){

}

//methods
string levelOneStrategy::takeAction(){
    return " has started to spread. We are making all citizens wear masks and social distancing. Stopping all international flights";
}