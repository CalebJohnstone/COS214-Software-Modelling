#include "levelFourStrategy.h"

//constructor and destructor
levelFourStrategy::levelFourStrategy(){

}

levelFourStrategy::~levelFourStrategy(){

}

//methods
string levelFourStrategy::takeAction(){
    return " is dangerous. Enforcing a strict lockdown.";
}