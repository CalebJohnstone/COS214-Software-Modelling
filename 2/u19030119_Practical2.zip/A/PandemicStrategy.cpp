#include "PandemicStrategy.h"

//constructor and destructor
PandemicStrategy::PandemicStrategy(){

}

PandemicStrategy::~PandemicStrategy(){

}