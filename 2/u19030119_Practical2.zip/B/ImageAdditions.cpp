#include "ImageAdditions.h"

//constructor and destructor
ImageAdditions::ImageAdditions(){

}

ImageAdditions::~ImageAdditions(){

}

void ImageAdditions::drawElement(Poster* element){
    this->addition = element;
}