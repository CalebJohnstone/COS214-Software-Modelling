#include "Poster.h"

//constructor and destructor
Poster::Poster(){

}

Poster::~Poster(){

}